package com.puseletsomaraba.bitcoinpriceupdate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {
    Spinner currency_spinner;
    TextView priceLabeltv;
    private final String TAG="maraba";

    private final String BASE_URL="https://apiv2.bitcoinaverage.com/indices/global/ticker/BTC";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        spinnerCurrency();





    }

    private void init()
    {
        currency_spinner=findViewById(R.id.currency_spinner);
        priceLabeltv=findViewById(R.id.priceLabel);

    }

    private void spinnerCurrency()
    {

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.currency_array,R.layout.spinner_item);



        spinnerAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
// Apply the adapter to the spinner
        currency_spinner.setAdapter(spinnerAdapter);

        //setup on selected item
        currency_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG,"index : "+position+" currency :"+parent.getItemAtPosition(position));
                String urlCurrency=BASE_URL+parent.getItemAtPosition(position);
                Log.d(TAG, "currency URL :" + urlCurrency);
                configNetwrk(urlCurrency);



            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d(TAG,"Nothing was selected on spinner");


            }
        });

    }

    private void configNetwrk(String url){

        Log.d(TAG,"NetworkConfig method accesed");
        AsyncHttpClient client = new AsyncHttpClient();
        client.get(url,new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                Log.d(TAG,": Network AsuncHttpClient connection SUCCESSFUL  ");
                Log.d(TAG, "JSONObject  file :" + response.toString());

                //extract json data
                try{
                    String price = response.getString("last");
                    priceLabeltv.setText(price);

                }catch(JSONException e){
                    //display error in console
                    e.printStackTrace();;

                }



                //pull jsn info

                //assign info to xml views
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                Log.d(TAG,": Error Network AsuncHttpClient connection FAILED");
                Log.e(TAG,"Error-->"+throwable);
                Toast.makeText(getApplicationContext(),"Network Connection Failed",Toast.LENGTH_SHORT).show();

            }
        });


    }
}
